# Summary

* [Act I — Codex KISA](act1_codex_kisa/README.md)
* [Act II — Absolutus](act2_absolutus/README.md)
* [Act III — Ardas](act3_ardas/README.md)
* [Act IV — Arkon](act4_arkon/README.md)
* [Act V — Trinexus](act5_trinexus/README.md)
* [Act VI — KISA 3.68](act6_kisa368/README.md)
